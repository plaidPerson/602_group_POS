
public class CashRegisterReport extends CashRegister{

	public CashRegisterReport() {
		// TODO Auto-generated constructor stub
	}

}
