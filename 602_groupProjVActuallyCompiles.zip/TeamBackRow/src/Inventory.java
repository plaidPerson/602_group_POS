import java.util.HashMap;

//Hashmap here holding ItemIn's

public class Inventory {
	
	
	//HashMap declaration
	private HashMap<String, ItemIn> myInventoryMap;

	public Inventory() {
		
		//This Map should really read in from a data File, but here is some sample data.
		//  Here, the ItemIn constructor accepts the arguments of Item first. 
		
		myInventoryMap = new HashMap<String, ItemIn>();
		
		//Data - put stuff into the HashMap
		
		//ItemIn Holds: (int itemBarcodeID,double sellPrice,int numberOfItems,
		//		numOfItemsInInventory,double buyPrice,supplier,	threshold);
		
		myInventoryMap.put("Apples", new ItemIn(001,00.50,15, 4, 00.20, "Sysco" ,   10));
		myInventoryMap.put("Bananas",new ItemIn(002,00.40,20, 5, 00.20, "Sysco" ,   10));

		myInventoryMap.put("CatFood",new ItemIn(003,12.95,25, 6, 10.00, "SuperValu",10));
		myInventoryMap.put("DogFood",new ItemIn(004,15.50,30, 7, 10.00, "SuperValu",10));
		
		
	}

}
