// ***** add be Meshal *****
import java.util.List;
import java.lang.reflect.Type;


public class Item {
	
//CLASS VARIABLES
	private int itemBarcodeID;
	private double sellPrice;
	private int numberOfItems;
	//We removed the supplier variable and put it in ItemIn
	//private String supplier;
	
	
//CONSTRUCTORS
	public Item() {
		
		//CLASS VARIABLES
		itemBarcodeID = 000;
		sellPrice = 0.0;
		numberOfItems = 1;
		// ***** add be Meshal *****
		//FileHandler.addInventory(this);
	
	
	}
	public Item(int barCode, int num) {
		
		//CLASS VARIABLES
		itemBarcodeID = barCode;
		sellPrice = 0.0;
		numberOfItems = num;
		
		// ***** add be Meshal *****
		//FileHandler.addInventory(this);
		
		//Look up the sellPrice in Inventory
		//sellPrice = ?
	
	}
	
//METHODS
	
	//Getter methods
	
	public int getItemBarcodeID()
	{
		return this.itemBarcodeID;
	}
	public double getSellPrice()
	{
		return this.sellPrice;
	}
	
	// ***** add be Meshal *****
	public double getNumberOfItems()
	{
		return this.numberOfItems;
	}
	
	//Setter methods
	public void setItemBarcodeID(int id)
	{
		this.itemBarcodeID = id;
	}
	
	public void setSellPrice(double sellPrice)
	{
		 this.sellPrice = sellPrice;
	}
	
	public void setNumberOfItems(int num)
	{
		this.numberOfItems = num;
	}
	// ***** add be Meshal *****
	private void addItem(){
		FileHandler.addInventory(this);
		
	}
	// ***** add be Meshal *****
	//------------------------------------------
	public static void main(String[] args){
		//Item a = new Item();
		Item b = new Item(001, 10);
		b.addItem();
		Item c = new Item(002, 22);
		c.addItem();
		Item d = new Item(003, 33);
		d.addItem();
		Item e = new Item(004, 140);
		e.addItem();
		Item f = new Item(005, 79);
		f.addItem();
		List<Item> test = FileHandler.getInventory();
		for(int i = 0; i < test.size(); i++){
			
			System.out.println(test.get(i).getItemBarcodeID());
			System.out.println(test.get(i).getSellPrice());
			System.out.println(test.get(i).getNumberOfItems());
		}
		
	}


}
