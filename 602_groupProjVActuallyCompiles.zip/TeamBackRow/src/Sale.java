import java.time.LocalTime;

public class Sale {
	
//CLASS VARIABLES

	
	private int saleID;
	
	private int sizeOfItemArray;
	
	//An array that holds all the items that are purchased.  Each
	//  element in the array has a itemBarcodeID, NumberOfItems,
	//  and, a price.
	private Item[] reciept;

	private int currentIndexOfReciept;
	
	private int numberOfItemsOnReciept;
	
	//note: CashRegister will calculate PriceAfterTax????
	private double totalPriceBeforeTax;
	
	private LocalTime saleTime;

//CONSTRUCTOR
	public Sale() {
		
		saleID = 0;
		
		sizeOfItemArray = 25;	
		
		//Create an array of Items that represents the customer receipt.
		reciept = new Item[sizeOfItemArray];
		
		currentIndexOfReciept = 0;
		
		numberOfItemsOnReciept = 0;
		
		totalPriceBeforeTax = 0.0;
		
		//reset this time when  checkout is complete
		
		saleTime.now();
	}
	
//METHODS
	//Getters
	
	public Item[] getReciept()
	{
		return this.reciept;
	}
	
	public int getItemBarcode()
	{
		return this.reciept[this.currentIndexOfReciept].getItemBarcodeID();
	}
	
//	public double getNumItems()
//	{
//		return this.reciept[this.currentIndexOfReciept].getNumberOfItems();
//	}
	
	//Setter Methods
	
	public void setSaleTime()
	{
		this.saleTime.now();
	}
	
	public void setReciept(int num, int barcodeID)
	{
		int i = this.currentIndexOfReciept;
		
		//Error is here...................................
		this.reciept[i].setNumberOfItems(num);
		this.reciept[i].setItemBarcodeID(barcodeID);
		
		this.increaseRecieptCounter();
		
	}
	
	public void setSaleID(int id) 
	{
		this.saleID = id;
		
	}
	
	public void setNumberOfItemsOnReciept(int i) 
	{
		this.numberOfItemsOnReciept = this.numberOfItemsOnReciept + i;
		
	}

	
	public void increaseRecieptCounter()
	{
		this.currentIndexOfReciept++;
		
	}
	
	double setTotalPriceBeforeTax(Item[] reciept)
	{
		//this method has NOT been implemented
		return 0;
	}
	
	void cancelItem()
	{
		
	}
	
	void cancelSale()
	{
		
	}
	
	//Mutator Method
	//////////////////////////this is where it breaks///////////////////////////////////////
	public void addItemsToSale(int itemBarcodeID, int numberOfItems, int itemCounter)
	{
		//Increase this.numberOfItemsOnReciept 
		
		setNumberOfItemsOnReciept(numberOfItems); 
		
		
		//Receipt can hold 25 items.
		System.out.println(" BarcodeID:" + itemBarcodeID + " numOfItems: " + numberOfItems + " itemCounter: " + itemCounter);
		
		System.out.println("" );
		System.out.println("reciept.length = " + reciept.length);
		System.out.println("");
		
		//ERROR HERE.......................................................................................................
		//...............This fails. It cannot access the items through the Item array, reciept................................................................................................

		System.out.println("this.reciept = " + this.reciept[itemCounter] );
		
		//..............................................................................................
		
		Item a = new Item();
		
		a.setItemBarcodeID(itemBarcodeID);
		a.setNumberOfItems(numberOfItems);
		
		 this.reciept[itemCounter] = a;
		 
		//this.reciept[itemCounter].setItemBarcodeID(itemBarcodeID);
		//this.reciept[itemCounter].setNumberOfItems(numberOfItems);
		
		System.out.println(" BarcodeID:" + itemBarcodeID + " numOfItems: " + numberOfItems + " itemCounter: " + itemCounter);
		
		//Locate the itemBarcodeID in Inventory and 
		//       find the items price.
		
		//Add that price*numberOfItems to the totalPriceBeforeTax class variable.
		
		//Increment to the next array index of the receipt
		//this.currentIndexOfReciept ++;
		
		//if array is too small, double its size here.
		
		//get the reciept
		
		//add items to the reciept

		//Decrease the Inventory by the numberOfItems in a method that Finalizes the Sale
		
		String s = this.reciept[itemCounter].toString();	
		System.out.println(""+s);
	   
	}
	
	void addItemsToTotalItemCount(int numberOfItems)
	{
		
	}
	
	void finalizeSale()
	{
		//Decrease the Inventory by the numberOfItems when Sale is finalized
		//Insert this Sale object into CashRegister's array salesOnThisRegisterToday[].
		//Insert this Sale object into the RegisterSession for this Employee, called saleIDsThisSession.
	}


}
