//These are importing Java classes.  Java builtLocalDate and LocalTime
//  objects inside this class.
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;

/*
 * File: CashRegister
 * 
 *   Employees log into a Session in order to access the CashRegister.
 *   There are multiple CashRegisters.  
 * 
 *   Date is an important class variable. Other classes will have to 
 *   perform checks against this Date.
 * 
 *   Theres an output to the console on line #110
 */
public class CashRegister {
	
//CLASS VARIABLES

	//Uniquely identifies this register
	private int registerID;
	
	//The Employee logged into the CashRegister
	private Employee e;
	
	//Employee cashier; this is stored in the Session????
	private int sessionArraySize;
	private int saleArraySize;
	
	private RegisterSession[] sessionsOnThisRegisterToday;
	//private Sale[] salesOnThisRegisterToday;
	
	private LocalDate todaysDate;
	private LocalTime currentTime;
	private LocalTime loggedOn;
	private LocalTime loggedOff;
	
	//These two variables receive user input.
	//For instance, Four bananas might force the user to input:
	//
	//      itemBarcodeID = 213
	//      NumberOfItems = 4
	//
	//  Cash Register should then output to the console:
	//
	//        4 bananas @ $0.50 = $2.00
	//
	//private int itemBarcodeID;
	//private int NumberOfItems;
	
	//This is the money in the register's drawer
	private double moneyFromALLSales;
	
	//More money variables here, if needed....
	
	private int numberOfSales;
	private int numberOfCancellations;
	private int numberOfReturns;
	
//CONSTRUCTOR #1
	public CashRegister() {
		
		//Uniquely identifies this register
		registerID = 0;

	    sessionArraySize = 10;
		saleArraySize = 10;
		
		RegisterSession[] sessionsOnThisRegisterToday = new RegisterSession[sessionArraySize];
		// Sale[] salesOnThisRegisterToday = new Sale[saleArraySize];
		
		//LocalDate todaysDate;
		//LocalTime currentTime;
		//LocalTime loggedOn;
		//LocalTime loggedOff;
		
		//These two variables receive user input.
		//For instance, Four bananas might force the user to input:
		//
		//      itemBarcodeID = 213
		//      NumberOfItems = 4
		//
		//  Cash Register should then output to the console:
		//
		//        4 bananas @ $0.50 = $2.00
		//
		//int itemBarcodeID = 000;
		//int NumberOfItems = 0;
		
		//This is the money in the register's drawer
		double moneyFromALLSales = 0.0;
		
		//More money variables if needed....
		
		int numberOfSales = 0;
		int numberOfCancellations = 0;
		int numberOfReturns = 0;
	}

	//Constructor #2.
	public CashRegister(int registerID,int sessionArraySize,int saleArraySize) 
	{
		
		//Uniquely identifies this register
		this.registerID = registerID;
		//Employee cashier; this is stored in the Session????
	    this.sessionArraySize = sessionArraySize;
		this.saleArraySize = saleArraySize;
		RegisterSession[] sessionsOnThisRegisterToday = new RegisterSession[sessionArraySize];
		Sale[] salesOnThisRegisterToday = new Sale[saleArraySize];
		
		LocalDate todaysDate;
		LocalTime currentTime;

		
		//These two variables receive user input.
		//For instance, Four bananas might force the user to input:
		//
		//      itemBarcodeID = 213
		//      NumberOfItems = 4
		//
		//  Cash Register should then output to the console:
		//
		//        4 bananas @ $0.50 = $2.00
		//
		//int itemBarcodeID = 000;
		//int NumberOfItems = 0;
		
		//This is the money in the register's drawer
		double moneyFromALLSales = 0.0;
		
		//More money variables if needed....
		
		int numberOfSales = 0;
		int numberOfCancellations = 0;
		int numberOfReturns = 0;
	}
	
//METHODS
//////////////////////////////////////////////////////
//GETTERS		
//////////////////////////////////////////////////////
		public LocalDate getTodaysDate()
		{
		return this.todaysDate;
		}
		
		//Return the time that the user logged onto register
		
		public LocalTime getLoggedOnTime()
		{
		return this.loggedOn;
		}
		
		public int getRegisterID()
		{	
			int i = 0;
			
			i = this.registerID;	
			
		return i;
		}
//////////////////////////////////////////////////////
//SETTERS		
//////////////////////////////////////////////////////
		public void setTodaysDate()
		{
			LocalDate d  = LocalDate.now(); 
			this.todaysDate = d;
			
		}
		
		//sets loginTime to now()
		
		public LocalTime setLoginTime()
		{
			LocalTime t = LocalTime.now(); 
			this.loggedOn = t;
			
		return this.loggedOn;
		}
		
		//sets login time to someTime
		
		public LocalTime setLoginTime(LocalTime someTime)
		{
			
			this.loggedOn = someTime;
			
		return this.loggedOn;
		}
		
		
		
		public void setRegisterID(int id)
		{	
			this.registerID = id;	
			
		}

		
		//This is the first output to a cashier who has already logged into a 
		//    CashRegister Session.
		public RegisterSession RunRegister(Employee e)
		{
			System.out.println("We have now entered the RunRegister(Empoyee e) method in CashRegister.java");
			System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
			System.out.println("    CASH REGISTER #" + this.getRegisterID());
			System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
			System.out.println("");	
			
			//Set and display time -> send to RegisterSession object
			LocalTime t0 = null;	
			t0 = t0.now();
			this.setLoginTime(t0);
			
			//set and display date ->send to RegisterSession object
			setTodaysDate();
			LocalDate d0 = getTodaysDate();
			
			int id = this.getRegisterID();
			//Create a new RegisterSession
			RegisterSession session = new RegisterSession(t0,d0, id, e);
			
			System.out.println("Login Date: " + getTodaysDate());
			System.out.println("Login Time: " + getLoggedOnTime());
			//System.out.println("Employee: " + this.getEmployeeLogin());
			//System.out.println("Employee session #: " + this.getCurrentSessionID ());
		
		return session;
		}
		
		public int displayMenu()
		{
			
			System.out.println("--------------------------");
			System.out.println("        MENU              ");
			System.out.println("--------------------------");
			System.out.println("");
			System.out.println("PRESS 0 - Logout");
			System.out.println("PRESS 1 - Begin Customer Checkout");
			System.out.println("PRESS 2 - ");
			System.out.println("PRESS 3 - Print Cashier Report");
			System.out.println("PRESS 4 - ");
			System.out.println("PRESS 5 - ");
			System.out.println("--------------------------");	
			System.out.print(">> ");	
			
			//User input
			Scanner reader = new Scanner(System.in);  
			int userMenuInput = reader.nextInt();
			
		return userMenuInput;	
		}
		
		//register_num_1.menuOptions(menuOptionReturn, s, saleNumber);///////////////////////////////////////
		
		
		public void menuOptions(int menuSelectionByUser, Sale s, int saleNumber) 
		{
			if (menuSelectionByUser == 0)
			{
				//The user has selected 'Logout'
				//Send the information from CashRegister into Session object.
				//Logout time must be stored in the instance variables of RegisterSession.
		
				//Note: There must be a new sessionID generated when an employee logs in.
				//  It should store data in the appropriate element of an array.
				//  For instance, the first time that someone logs in that day, it is 
				//  stored in sessionsOnThisRegisterToday[0].  
				// The second time, its stored in sessionsOnThisRegisterToday[1]
				
				//The time this employee logged off for RegisterSession sessionID = 0.
				
			
			
			}
			if (menuSelectionByUser == 1)
			{
				checkout(s, saleNumber);
			}
			if (menuSelectionByUser == 2)
			{
				
				
			}
			if (menuSelectionByUser == 3)
			{
				//Find the following method in CashierReport.java (which inherits from CashRegister)
				//public void printToFile() throws IOException
				//call that method here.
				
				//How do we access a method in CashRegister report when the object
				// that calls this method is of type 
				
				CashierReport report = new CashierReport();
				//report.printEmployeeInfo();
				
			}
		
		
		}

		
		private Sale checkout(Sale s, int id)
		{
			int numberOfItems = 0;
			int barcode = 0;
			
			s.setSaleID(id);
			
			System.out.println("--------------------------");
			System.out.println("       Sale #" + id );
			System.out.println("--------------------------");
			System.out.println(" To end the sale, press 'q' ");
			
			while(numberOfItems != 'q' && barcode != 'q')
			{
				//set s.saletime
				
				int itemCounter = 0;
		
				Scanner reader = new Scanner(System.in);
				
			
				//User inputs the items barcode number
				
				System.out.println("Enter item Barcode # >>");
				barcode = reader.nextInt(); 
			
				//User inputs the number of items 
				
				System.out.println("Enter Number of items >>");
				numberOfItems = reader.nextInt();
				
			
				//put the item on the reciept and increment the 
				//IF RECIEPT IS OUT OF ROOM BECAUSE MORE THAN 25 ENTRYS SHAVE BEEN MADE, MAKE SALE ARRAY LARGER
				//s.setReciept(numberOfItems, barcode);
				
				s.addItemsToSale(barcode,numberOfItems,itemCounter);
				
				//itemCounter ++;
				
				
				//Output information about the product that was just rung up.
				
				System.out.println("" + numberOfItems + "ItemName @ priceOfItem = TotalPriceForTheseItems");
				System.out.println("--------------------------------------------------------------------");
			}
			
			s.setSaleTime();
			
		return s;
		}
		
		private double calculateTotalBeforeTax()
		{
			double totalBeforeTax = 0;
			
			
			return totalBeforeTax;
		}
		
		//NOTE: FOOD AND CLOTHES DO NOT HAVE TAX....????
		private double calculateTotalAfterTax(int totalBeforeTax)
		{
			double totalAfterTax = 0;
			
			totalAfterTax = totalBeforeTax * 0.65;		
			
			return totalAfterTax;
		}
		
		private void saveSaleToFile()
		{
			
		}
		

	
	
	
}
