//This is inherited from Item class. It contains additional info regarding Items in 
//    Inventory.

//These items get put in a hashmap in inventory, I think

public class ItemIn extends Item
{

//CLASS VARIABLES
		private int numOfItemsInInventory;
		private double buyPrice;
		private String supplier;
		private int threshold;
		
//CONSTRUCTOR #1
		
	public ItemIn() 
	{
		
		numOfItemsInInventory = 0;
		double buyPrice = 0.0;
		String supplier = "";
		threshold = 0;
	}
//CONSTRUCTOR #2
	
	public ItemIn(int numOfItemsInInventory, double buyPrice, String supplier, int threshold) 
	{
		
		this.numOfItemsInInventory = numOfItemsInInventory;
		this.buyPrice = buyPrice;
		this.supplier = supplier;
		this.threshold = threshold;
	}
//CONSTRUCTOR #3. This one accepts all the variables for Item and then all the 
	//variables for ItemIn.  This constructor is used in the HashMap in Inventory.java.

	public ItemIn(int itemBarcodeID, double sellPrice, int numberOfItems, int numOfItemsInInventory, double buyPrice, String supplier, int threshold) 
	{
		this.setItemBarcodeID(itemBarcodeID);
		this.setSellPrice(sellPrice);
		this.setNumberOfItems(numberOfItems);
		
		this.numOfItemsInInventory = numOfItemsInInventory;
		this.buyPrice = buyPrice;
		this.supplier = supplier;
		this.threshold = threshold;
	}
}
