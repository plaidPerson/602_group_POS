import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;

public class Driver {

	public Driver() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws Exception {
		
		//LOCAL VARIABLES ARE DECLARED/////////////////////////////////
		
		int saleArraySize = 10;
		
		int sessionArraySize = 10;
		
		int register_num = 1;
		
		int sessionNumber = 0;
		
		int saleNumber = 0;
		
		int menuOptionReturn = 0;
		
		
		//Create a String object called userName FOR USER TO LOG INTO THE SYSTEM////
		
		String userName = " ";
		
		String password = " ";
		
		//Create a boolean object called passwordValid
				
		boolean passwordValid = false;
		
		String sessionPrint = " ";
		
		//OBJECTS ARE DECLARED////////////////////////////////////////
		
		Driver d = new Driver();

		CashRegister register_num_1 = new CashRegister(1,10,10);
		
		register_num_1.setRegisterID(1);

		// Sale is declared inside RegisterSession.
		Sale s = new Sale();
		
		//WRITE A FUNCTION HERE TO ACCEPT USER INPUT ON WHICH REGISTER THEY ARE LOGGING INTO.
		
		
		
		
		
		Employee e = new Employee();
	
		
		//METHOD CALLS///////////////////////////////////////////////////
		/////////////////////////////////////////////////////////////////
		//STEP 1. USER LOGS INTO THE SYSTEM BY ENTERING NAME AND PASSWORD.
		/////////////////////////////////////////////////////////////////
		
		//Driver object prompts the user to enter their username.
		
		userName = d.login();
		
		//Employee object loads employee data.
		
		e.loadData(userName);
		
		//Driver object checks if the employee exists.
		
		d.employeeExists(userName, e);

		//Driver object prompts the user to enter their system password.
		
		password = d.getPasswordFromUser();
		
		
		//Employee object checks if user input matched a valid username and password in the system.
		
		passwordValid = e.tryPassword(password);
		
		//While the password is NOT valid, re-promt the user.
		
		while (passwordValid == false)
		{
			System.out.println("That password was incorrect !");
			
			password = d.getPasswordFromUser();
			passwordValid = e.tryPassword(password);
		}
	
		System.out.println(" ");
		System.out.println(" ");
		
		//User is now logged into the cash register system. 
		//A new Session starts. A new Session object is created.
		//The register object calls method runRegister and passes the employee as a parameter.
		
		RegisterSession session = new RegisterSession(register_num_1.setLoginTime(), register_num_1.getTodaysDate(), sessionNumber, e);
		session = register_num_1.RunRegister(e);

		
		System.out.println(" ");
		System.out.println(" ");
		
		//Session object gets returned from the RunRegister method. It is output to the console.
		
		sessionPrint = session.toString();
		System.out.println(" ");
		
		System.out.println(sessionPrint);
		System.out.println(" ");
		
		//Display menu
		
		menuOptionReturn = register_num_1.displayMenu();
		
		//displayMenu() will return an int value. It must get passed into the 
		//menuOptions(int menuSelectionByUser) method in CashRegister.java
		
		//if menuOption = 2, then start checkout process.
		//if menuOption = 3, then Output data from CashierReport to file called CashierReportOutput.txt
		
		register_num_1.menuOptions(menuOptionReturn, s, saleNumber);
		
		//session.
		
		
	}
    //Read from/write to a file:
	//https://www.tutorialspoint.com/java/java_files_io.htm
	

	
	public boolean employeeExists(String input, Employee emp)
	{
		
		boolean result = false;
	
		
		
				if (emp.getEmployeeLogin().equals(input))
				{
					System.out.println("");
					System.out.println("Employee Exists");
					System.out.println("");
					result = true;
				}
				else
				{
					System.out.println("Output 4. Employee DOES NOT Exist");
					System.out.println("Locate your login and password in file: Employee.java - the loadData method");
					result = false;
				}
		
	return result;
	}
	

	public String login()
	{
		
		//System.out.println("");
		System.out.println("???????????????????????????????");
		System.out.println("        Login   ");
		System.out.println("???????????????????????????????");
		System.out.println("");
	
		//User input
		Scanner reader = new Scanner(System.in);  
		String userInput = "";
			
		    System.out.println("");	
		    System.out.println(" ");
		    System.out.println("Please enter your username >> ");		
			userInput = reader.nextLine();
			
	return userInput;	
	}
	
	public String getPasswordFromUser()
	{

		//User input
		Scanner reader = new Scanner(System.in);  
		String userInput = "";

		   
			System.out.print("Please enter your password>> ");		
			userInput = reader.nextLine();
			
	return userInput;	
	}
	
}//end of class
