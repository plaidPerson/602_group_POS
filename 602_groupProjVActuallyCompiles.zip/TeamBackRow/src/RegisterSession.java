import java.time.LocalDate;
import java.time.LocalTime;

//File: RegisterSession
/*
 * Methods need to be declared private where possible.
 */
public class RegisterSession {
	
//CLASS VARIABLES
	
	//unique id to each RegisterSession
	private int sessionID;
	
	private Employee employeeLoggedIn;
	private int registerID;

	//Everytime a new sale is made, this value increments up.
	//If there have been three sales, then there should exist:
	//sales[0], sales[1], and sales[2]
	
	private int numberOfSalesThisSession;
	
	private int sizeOfSalesArray;
	private Sale[] salesInThisSession;

	private LocalDate today;
	
	private LocalTime loggedOn;
	private LocalTime loggedOff;

//CONSTRUCTOR
	RegisterSession(LocalTime t, LocalDate d, int id, Employee e)
	{
	//CLASS VARIABLES
	
		//unique id to each RegisterSession
		//sessionID = ;
		
		//set this now
		employeeLoggedIn = e;
		
		//set this now
		registerID = id;
		
		sizeOfSalesArray = 10;

		Sale[] salesInThisSession = new Sale[sizeOfSalesArray];
		
		
//		for (int i = 0 ; i < sizeOfSalesArray; i++)
//		{
//			salesInThisSession[i].
//		}
		
		
		numberOfSalesThisSession = 0;
		
		this.today = d;
		
		this.loggedOn = t;
		
		//set this when cashier logs off
		//LocalTime loggedOff;

	}

//METHODS
	
	//Getter Methods////////////////////////////////////////////////////////////////
	
	//This session will have a logged in employee. 
	//Return their employeeLogin.
	
	String getEmployeeID()
	{
		return this.employeeLoggedIn.getEmployeeLogin();
	}
	
	//unique id to each register
	
	int getRegisterNumber()
	{
		return this.registerID;
	}
	
	//This session number is unique to this register today.
	
	int getSessionID()
	{
		return this.sessionID;
	}
	
	//is this counter necessary
	
	int getNumberOfSalesThisSession()
	{
		return this.numberOfSalesThisSession;
	}
	
	Sale[] getSalesInThisSession()
	{
		return this.salesInThisSession;
	}
	
	int getSizeOfSalesArray()
	{
		return this.sizeOfSalesArray;
	}
	
	LocalDate getDate()
	{
		return this.today;
	}
	
	LocalTime getLoggedOnTime()
	{
		return this.loggedOn;
	}
	
	LocalTime getLoggedOffTime()
	{
		return this.loggedOff;
	}
	
	//SETTERS////////////////////////////////////////////////////////////////////////////
	
	Sale[] setSalesInThisSession(int i, Sale s)
	{
		this.salesInThisSession[i] = s;
		
		return this.salesInThisSession;
	}
	
	public String salesToString()
	{
		String s = "", t = "";
		
		for (int i = 0 ; i < this.sizeOfSalesArray; i++)
		{
			s = ("Sale[" + i + "] = ");// + this.salesInThisSession[i] + " \n" );
			t.concat(s);
		}
		
	return t;	
	}
	
	
	public String toString()
	{
		String s = "";
		
		System.out.println("This RegisterSession contains:");
		System.out.println("------------------------------");
		System.out.println("sessionID: " + this.sessionID);
		System.out.println("registerID: " + this.registerID);
		System.out.println("Employee thats logged in : " + this.employeeLoggedIn);
	//	System.out.println("numberOfSalesThisSession: " + this.numberOfSalesThisSession);
		System.out.println("salesInThisSession: " + this.salesInThisSession);
		
		//this has an error//////////////////////////////////////////////////////
		
		String k = "";
		k = salesToString();
		
		System.out.println("" + k);
		System.out.println("sizeOfSalesArray: " + this.sizeOfSalesArray);
		System.out.println("Todays date: " + this.today);
	
		System.out.println("The time this employee logged on: " + this.loggedOn);
		System.out.println("The time this employee logged off: " + this.loggedOff);
	
		s = "sessionID: " + this.getSessionID() + ", " + 
		    "registerID: " + this.getRegisterNumber()+ ", " + 
			"The employee LoggedIn is: " + this.getEmployeeID() + ", " +
		    "numberOfSalesThisSession: " + this.getNumberOfSalesThisSession() + ", " +
		    "All SaleIDsInThisSession: " + this.getSalesInThisSession() + ", " + 
		    "sizeOfSalesArray: " + this.getSizeOfSalesArray() + ", " +
		    "Date: " + this.getDate() + ", " + 
		    "Time Logged on: " + this.getLoggedOnTime() + ", " +
		    "Time Logged off: " + this.getLoggedOffTime();

	return s;			
	}
}
