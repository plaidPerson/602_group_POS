import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/*
 * File: CashierReport
 * 
 * This class extends File: Employee.java
 * 
 *       This Class will write the information from Employee class to a file
 *       every time that Employee logs out of a session.  Each employee will 
 *       have their own unique file holding their CashierResport. 
 *       
 *       Note: These method return types are likely to change, for instance
 *       PrintToFile() might output an object of type FileStream, or something.
 *       Meshal's looking into this. Check with him. 
 *       
 */
public class CashierReport extends Employee
{
	//Class Variables
	

	//Constructor
	public CashierReport()
	{
		
	}
	
	//Class Methods
	public void printEmployeeInfo() throws IOException
	{
		//Make the file output Employee information: Full name, id# (login), Any Session information, etc.
		
		
		File exportedFile = new File("CashierReportOutput.txt"); 
		
		
		//define the path and file location

		PrintWriter out = new PrintWriter(new FileWriter(exportedFile)); 
		
		System.out.println(exportedFile.canWrite());
		
		//Output to  report - SOMETHING IS BROKEN HERE. It wrote before
		out.println("File: CahierReportOutput.txt");
		out.println("This File contains information about a cashier.");
		out.println("");
		out.println("Employee Name: ");
		out.println("Employee login ID: ");
		out.println("Employee Session ID: ");
		out.println("Employee Sale ID: ");
		
		out.close();
		
		
	}
	
	public void printToFile() throws IOException
	{
		

		
		
	}
	
	public void readFromFile()
	{
		//Read from a txt file contained within the project 
		//  (dragged and dropped inside)
		File importedFile = new File("ImportCahierReport.txt"); 
		
		//In inRef = new In(importedFile);
		
		System.out.println("importedFile: " + importedFile);
		
		
		
	}
	

}
