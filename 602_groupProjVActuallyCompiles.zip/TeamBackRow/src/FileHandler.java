import java.io.*;
import java.lang.reflect.Type;
import java.util.List;

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;



public class FileHandler {
	
	public static void addInventory(Item I){
		
		
		try {
			
			List<Item> existingInventory = getInventory();
			existingInventory.add(I);
			Writer writer = new FileWriter("Inventory.json");

			Gson gson = new GsonBuilder().create();
			gson.toJson(existingInventory, writer);
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static List<Item> getInventory(){
		try{
			
			Gson gson = new Gson();
			

			JsonReader reader = new JsonReader(new FileReader("Inventory.json"));
			
			Type objType = new TypeToken<List<Item>>() { }.getType();
			
			List<Item> data = gson.fromJson(reader, objType);
			reader.close();
			return data;
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

}
