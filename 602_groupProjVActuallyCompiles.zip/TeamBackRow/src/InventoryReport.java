//THis inherits from the Inventory class
public class InventoryReport extends Inventory{

	public InventoryReport() {
		
	}
//METHODS
	
	//Output the inventory to console 
	
	//output the inventory to the file.

}
